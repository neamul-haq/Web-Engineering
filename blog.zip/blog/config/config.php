<?php
define("DB_HOST", "localhost");
define("DB_USER", "root");
define("DB_PASS", "");
define("DB_NAME", "neamul");
define("TITLE", "E-Learning");
define("KEYWORDS", "cpu, gpu, windows, linux, mac os, ios, android, social");
?>